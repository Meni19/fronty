const { Type } = require("../models/models");
const ApiError = require("../error/ApiError");

class TypeController {
  // POST http://localhost:5000/api/type
  async create(req, res, next) {
    try {
      const { name } = req.body;
      const existingType = await Type.findOne({ where: { name } });
      if (existingType) {
        throw new Error("Тип с таким именем уже существует.");
      }
      const type = await Type.create({ name });
      return res.json(type);
    } catch (error) {
      next(ApiError.badRequest(error.message));
    }
  }

  // GET http://localhost:5000/api/type
  async getAll(req, res) {
    try {
      const types = await Type.findAll({
        attributes: { exclude: ["createdAt", "updatedAt"] },
      });
      return res.json(types);
    } catch (error) {
      return res.status(500).json({ error: "Внутренняя ошибка сервера" });
    }
  }

  // DELETE http://localhost:5000/api/type/del/:id
  async deleteType(req, res, next) {
    const typeId = req.params.id;
    try {
      const type = await Type.findByPk(typeId);
      if (!type) {
        const error = new ApiError(404, "Тип не найден");
        return next(error);
      }
      await type.destroy();
      return res.json({ message: "Тип успешно удален" });
    } catch (error) {
      return next(ApiError.internal(error.message));
    }
  }

 // PUT http://localhost:5000/api/type/update/:id
async updateType(req, res, next) {
    const typeId = req.params.id;
    const { name } = req.body;

    try {
        const type = await Type.findByPk(typeId);

        if (!type) {
            const error = new ApiError(404, "Тип не найден");
            return next(error);
        }

        const existingType = await Type.findOne({ where: { name: name } });
        if (existingType) {
            throw new Error("Тип с новым именем уже существует.");
        }

        type.name = name;
        await type.save();

        return res.json({ message: "Имя типа успешно изменено" });
    } catch (error) {
        return next(ApiError.internal(error.message));
    }
}

}

module.exports = new TypeController();
