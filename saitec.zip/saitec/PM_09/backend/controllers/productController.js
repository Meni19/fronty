const uuid = require('uuid')
const path = require('path')
const { Product, Brand, Type } = require('../models/models')
const ApiError = require('../error/ApiError')

class ProductController {

    // POST http://localhost:5000/api/product - FormData
    async create(req, res, next) {
        try {
            const { name, price, amount, size, description, year, brandId, typeId } = req.body
            const { img } = req.files
            const existingBrand = await Brand.findByPk(brandId);
            if (!existingBrand) {
                throw new Error("Бренд с указанным идентификатором не существует.");
            }
            const existingType = await Type.findByPk(typeId);
            if (!existingType) {
                throw new Error("Тип с указанным идентификатором не существует.");
            }
            const existingProduct = await Product.findOne({ where: { name } })
            if (existingProduct) {
                throw new Error("Продукт с таким именем уже существует.")
            }
            const fileName = uuid.v4() + ".jpg"
            img.mv(path.resolve(__dirname, '..', 'static', fileName))
            const product = await Product.create(
                { name, img: fileName, price, amount, size, description, year, brandId, typeId },
                { attributes: { exclude: ['createdAt', 'updatedAt'] } }
            )
    
            return res.json(product)
        } catch (error) {
            next(ApiError.badRequest(error.message))
        }
    }
    
    
    

    // GET http://localhost:5000/api/product
    async getAll(req, res) {
        try {
            let { brandId, typeId, limit, page } = req.query
            page = page || 1
            limit = limit || 17
            let offset = (page - 1) * limit
            let whereClause = {}
            if (brandId) {
                whereClause.brandId = brandId
            }
            if (typeId) {
                whereClause.typeId = typeId
            }
            const products = await Product.findAndCountAll({
                where: whereClause,
                limit: parseInt(limit),
                offset: parseInt(offset),
                attributes: {
                    exclude: ['updatedAt', 'createdAt'],
                },
                include: [
                    { model: Brand, attributes: ['name'], as: 'brand' },
                    { model: Type, attributes: ['name'], as: 'type' }
                ],
                order: [['id']]
            })
            const response = {
                count: products.count,
                rows: products.rows.map(product => {
                    return {
                        id: product.id,
                        name: product.name,
                        description: product.description,
                        img: product.img,
                        price: product.price,
                        amount: product.amount,
                        size: product.size,
                        brand: product.brand.name,
                        type: product.type.name
                    }
                })
            }
            return res.json(response)
        } catch (error) {
            return res.status(500).json({ error: 'Внутренняя ошибка сервера' })
        }
    }
    
    // GET http://localhost:5000/api/product/:id
    async getOne(req, res) {
        try {
            const { id } = req.params
            const product = await Product.findOne({
                where: { id },
                attributes: {
                    exclude: ['updatedAt', 'createdAt']
                },
                include: [
                    { model: Brand, attributes: ['name'], as: 'brand' },
                    { model: Type, attributes: ['name'], as: 'type' }
                ]
            })
            if (!product) {
                return res.status(404).json({ error: 'Продукт не найден' })
            }
            const response = {
                id: product.id,
                name: product.name,
                description: product.description,
                img: product.img,
                price: product.price,
                amount: product.amount,
                size: product.size,
                brand: product.brand.name,
                type: product.type.name
            }
            return res.json(response)
        } catch (error) {
            return res.status(500).json({ error: 'Внутренняя ошибка сервера' })
        }
    }
    
    // DELETE http://localhost:5000/api/product/del/:id
    async deleteProduct(req, res, next) {
        const productId = req.params.id
        try {
            const product = await Product.findByPk(productId) 
            if (!product) {
                const error = new ApiError(404, 'Товар не найден')
                return next(error)
            }
            await product.destroy()
            return res.json({ message: 'Товар успешно удален' })
        } catch (error) {
            return next(ApiError.internal(error.message))
        }
    }

}

module.exports = new ProductController()
