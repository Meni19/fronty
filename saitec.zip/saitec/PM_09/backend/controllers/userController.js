const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const { User, Basket } = require("../models/models");
const ApiError = require("../error/ApiError");

const generateJwt = (id, email, role) => {
  return jwt.sign({ id, email, role }, process.env.SECRET_KEY, {
    expiresIn: "24h",
  });
};
  // POST http://localhost:5000/api/user/registration
  class UserController {
    async registration(req, res, next) {
      try {
        const {
          name,
          surname,
          patronymic,
          login,
          email,
          password,
          confirmPassword,
          rules,
          role,
        } = req.body;
        const checkLogin = await User.findOne({ where: { login } });
        const checkEmail = await User.findOne({ where: { email } });
        const loginRegex = /^[a-zA-Z0-9-]+$/;
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        const nameRegex = /^[A-Za-z\u0400-\u04FF\s-]+$/;
        if (!name || !surname || !login || !email || !password) {
          throw ApiError.badRequest("Не все обязательные поля заполнены");
        }
        if (!loginRegex.test(login)) {
          throw ApiError.badRequest("Недопустимый формат логина");
        }
        if (!nameRegex.test(name)) {
          throw ApiError.badRequest("Имя содержит недопустимые символы");
        }
        if (!nameRegex.test(surname)) {
          throw ApiError.badRequest("Фамилия содержит недопустимые символы");
        }
        if (!nameRegex.test(patronymic)) {
          throw ApiError.badRequest("Отчество содержит недопустимые символы");
        }
        if (password.length < 6) {
          throw ApiError.badRequest("Пароль должен быть не менее 6 символов");
        }
        if (password !== confirmPassword) {
          throw ApiError.badRequest("Пароль и подтверждение пароля не совпадают");
        }
        if (!email.match(emailRegex)) {
          throw ApiError.badRequest("Некорректный формат электронной почты");
        }
        if (checkLogin) {
          throw ApiError.badRequest(
            "Пользователь с таким логином уже существует"
          );
        }
        if (checkEmail) {
          throw ApiError.badRequest("Пользователь с такой почтой уже существует");
        }
        if (rules === false) {
          throw ApiError.badRequest("Необходимо принять правила регистрации");
        }
        const hashPassword = await bcrypt.hash(password, 5);
        const user = await User.create({
          name,
          surname,
          patronymic,
          login,
          email,
          password: hashPassword,
          role,
        });
        const basket = await Basket.create({ userId: user.id });
        const token = generateJwt(user.id, user.email, user.role);
        return res.json({ token });
      } catch (error) {
        next(ApiError.badRequest(error.message));
      }
    }

  // POST http://localhost:5000/api/user/login
  async login(req, res, next) {
    const { login, password } = req.body;
    const user = await User.findOne({ where: { login } });
    if (!user) {
      return next(ApiError.internal("Пользователь не найден"));
    }
    let comparePassword = bcrypt.compareSync(password, user.password);
    if (!comparePassword) {
      return next(ApiError.internal("Указан неверный пароль"));
    }
    const token = generateJwt(user.id, user.email, user.role);
    return res.json({ token });
  }

  // GET http://localhost:5000/api/user/auth + Header
  async check(req, res, next) {
    const token = generateJwt(req.user.id, req.user.email, req.user.role);
    return res.json({ token });
  }

  // DELETE http://localhost:5000/api/user/del/:id
  async deleteUser(req, res, next) {
    const userId = req.params.id;
    try {
      const user = await User.findByPk(userId);
      if (!user) {
        const error = new ApiError(404, "Пользователь не найден");
        return next(error);
      }
      await user.destroy();
      return res.json({ message: "Пользователь успешно удален" });
    } catch (error) {
      return next(ApiError.internal(error.message));
    }
  }

  // POST http://localhost:5000/api/user/emails
  async checkEmailExists(req, res, next) {
    try {
      const { email } = req.body;

      const user = await User.findOne({ where: { email } });

      return res.json({ exists: Boolean(user) });
    } catch (error) {
      next(ApiError.internal(error.message));
    }
  }

  // GET http://localhost:5000/api/user
  async getAllUsers(req, res, next) {
    try {
      const users = await User.findAll({
        attributes: ["id", "email", "name"],
      });

      return res.json({ users });
    } catch (error) {
      next(ApiError.internal(error.message));
    }
  }

  // GET http://localhost:5000/api/user/id
  async getUserById(req, res, next) {
    try {
      const userId = req.params.id;

      // Fetch user data excluding role and password
      const user = await User.findByPk(userId, {
        attributes: { exclude: ["role", "password", "createdAt", "updatedAt"] },
      });

      if (!user) {
        const error = new ApiError(404, "Пользователь не найден");
        return next(error);
      }

      return res.json({ user });
    } catch (error) {
      next(ApiError.internal(error.message));
    }
  }

  // PUT http://localhost:5000/api/user/:id
  async editUserDetails(req, res, next) {
    try {
      const userId = req.params.id;
      const { name, surname, patronymic, login, email } = req.body;

      const user = await User.findByPk(userId);

      if (!user) {
        const error = new ApiError(404, "Пользователь не найден");
        return next(error);
      }
      user.name = name || user.name;
      user.surname = surname || user.surname;
      user.patronymic = patronymic || user.patronymic;
      user.login = login || user.login;
      user.email = email || user.email;

      await user.save();

      return res.json({ message: "Данные пользователя успешно обновлены" });
    } catch (error) {
      next(ApiError.internal(error.message));
    }
  }
}

module.exports = new UserController();
