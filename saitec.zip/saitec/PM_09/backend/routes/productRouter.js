const Router = require('express')
const router = new Router()
const ProductController = require('../controllers/productController')
const checkRole = require('../middleware/checkRoleMiddleware')

router.post('/', checkRole('ADMIN'), ProductController.create)
router.delete('/del/:id', checkRole('ADMIN'), ProductController.deleteProduct)
router.get('/', ProductController.getAll)
router.get('/:id', ProductController.getOne)

// POST http://localhost:5000/api/product
// DELETE http://localhost:5000/api/product/del/:id 
// GET http://localhost:5000/api/product
// GET http://localhost:5000/api/product/:id

module.exports = router