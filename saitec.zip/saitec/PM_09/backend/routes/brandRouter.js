const Router = require('express')
const router = new Router()
const BrandController = require('../controllers/brandController')
const checkRole = require('../middleware/checkRoleMiddleware')

router.post('/', checkRole('ADMIN'), BrandController.create)
router.delete('/del/:id', checkRole('ADMIN'), BrandController.deleteBrand)
router.put('/update/:id', checkRole('ADMIN'), BrandController.updateBrand);
router.get('/', BrandController.getAll)

// POST http://localhost:5000/api/brand
// DELETE http://localhost:5000/api/brand/del/:id
// GET http://localhost:5000/api/brand
// PUT http://localhost:5000/api/brand/update/:id

module.exports = router