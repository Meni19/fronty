import "./ProductListStyles.css"
import React, { useEffect, useState } from "react";
import Modal from "react-modal";
import ProductCard from "../product_card/ProductCard";
import ProductPage from "../product_page/ProductPage";
import { fetchProducts } from "../../../APIs/product/ProductAPI";

function ProductList({ page, setPage, limit, selectedType, selectedBrand }) {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [hasMorePages, setHasMorePages] = useState(true);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    const fetchData = async () => {
      try {
        const data = await fetchProducts(
          selectedBrand,
          selectedType,
          limit,
          page
        );

        setProducts(data.rows || []);
        setHasMorePages(data.count > page * limit);
        setLoading(false);
      } catch (error) {
        console.error("Ошибка при получении товаров:", error);
        setLoading(false);
      }
    };

    fetchData();
  }, [page, limit, selectedType, selectedBrand]);

  const handleNextPage = () => {
    if (hasMorePages) {
      setPage(page + 1);
    }
  };

  const handleCardClick = (product) => {
    setSelectedProduct(product);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setSelectedProduct(null);
    setIsModalOpen(false);
  };

  // Функция для фильтрации товаров по запросу поиска
  const filteredProducts = products.filter((product) =>
    product.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (loading) {
    return <p>Загрузка...</p>;
  }

  return (
    <div className="products-list">
      {/* Поле ввода для поиска */}
      <input
        className="search"
        type="text"
        placeholder="Поиск..."
        value={searchQuery}
        onChange={(e) => setSearchQuery(e.target.value)}
      />

      <div className="list">
        {filteredProducts.length > 0 ? (
          filteredProducts.map((product) => (
            <ProductCard
              key={product.id}
              img={process.env.REACT_APP_API_URL + product.img}
              name={product.name}
              brand={product.brand}
              price={product.price}
              onClick={() => handleCardClick(product)}
            />
          ))
        ) : (
          <p>Нет доступных товаров.</p>
        )}
      </div>

      {filteredProducts.length > 0 && (
        <div className="buttons">
          <button
            className="left"
            onClick={() => setPage(page - 1)}
            disabled={page <= 1}
          >
            <img className="left-arrow" src="/images/left.svg" alt="left" />
          </button>
          <button
            className="right"
            onClick={handleNextPage}
            disabled={!hasMorePages}
          >
            <img className="right-arrow" src="/images/right.svg" alt="right" />
          </button>
        </div>
      )}

      <Modal
        className="product-modal"
        isOpen={isModalOpen}
        onRequestClose={closeModal}
        contentLabel="Product Details Modal"
        appElement={document.getElementById("root")}
      >
        <ProductPage product={selectedProduct} onRequestClose={closeModal} />
      </Modal>
    </div>
  );
}

export default ProductList;
