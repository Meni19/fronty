import "./ProductCardStyles.css";

function ProductCard({ onClick, img, name, brand, price }) {
  const formattedPrice = new Intl.NumberFormat("ru-RU").format(price) + " ₽";

  return (
    <div className="card" onClick={onClick}>
      <img className="image" src={img} alt="Product" />
      <div className="name">{name}</div>
      <div className="brand">{brand}</div>
      <div className="price">{formattedPrice}</div>
    </div>
  );
}

export default ProductCard;
