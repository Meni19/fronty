import "./ListsStyles.css";

import React, { useState, useEffect } from "react";
import { fetchProducts } from "../../APIs/product/ProductAPI";
import { fetchBrands, deleteBrand } from "../../APIs/product/BrandAPI"

function BrandList() {
  const [brands, setBrands] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchBrandData = async () => {
      try {
        const data = await fetchBrands();
        setBrands(data || []);
        setLoading(false);
      } catch (error) {
        console.error("Ошибка при получении брендов:", error);
        setLoading(false);
      }
    };

    fetchBrandData();
  }, []);

  const handleDeleteBrand = async (brandId) => {
    try {
      const productsWithThisBrand = await fetchProducts(null, brandId, 1, 1);

      if (productsWithThisBrand.rows.length > 0) {
        alert("Нельзя удалить бренд, так как к нему прикреплены товары.");
      } else {
        const confirmDelete = window.confirm(
          "Вы уверены, что хотите удалить этот бренд?"
        );

        if (confirmDelete) {
          const response = await deleteBrand(brandId);

          if (response.error) {
            alert(response.error);
          } else {
            setBrands((prevBrands) =>
              prevBrands.filter((brand) => brand.id !== brandId)
            );
          }
        }
      }
    } catch (error) {
      console.error("Ошибка при удалении типа:", error);
    }
  };

  if (loading) {
    return <p>Загрузка брендов...</p>;
  }

  return (
    <div className="main-list">
      <h2>Список брендов</h2>
      {brands.length > 0 ? (
        <ul>
          {brands.map((brand) => (
            <li className='items-list' key={brand.id}>
              {brand.name}{" "}
              <button className='delete-button' onClick={() => handleDeleteBrand(brand.id)}>
                Удалить
              </button>
            </li>
          ))}
        </ul>
      ) : (
        <p>Нет доступных брендов.</p>
      )}
    </div>
  );
}

export default BrandList;
