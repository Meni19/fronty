import "./ListsStyles.css";
import React, { useState, useEffect } from "react";
import { getAllUsers } from "../../APIs/user/UserAPI";

function UserList() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const data = await getAllUsers();
        setUsers(data.users || []);
        setLoading(false);
      } catch (error) {
        console.error("Ошибка при получении пользователей:", error);
        setLoading(false);
      }
    };

    fetchUserData();
  }, []);

  const usersPerPage = 3;
  const totalPages = Math.ceil(users.length / usersPerPage);

  const handleClickNext = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % totalPages);
  };

  const handleClickPrev = () => {
    setCurrentIndex((prevIndex) => (prevIndex - 1 + totalPages) % totalPages);
  };

  if (loading) {
    return <p>Загрузка пользователей...</p>;
  }

  const start = currentIndex * usersPerPage;
  const end = start + usersPerPage;
  const currentUsers = users.slice(start, end);

  return (
    <div >
      <h2>Список пользователей</h2>
      {currentUsers.length > 0 ? (
        <>
          <table>
            <thead>
              <tr>
                <th>ID</th>
                <th>Email</th>
                <th>Name</th>
              </tr>
            </thead>
            <tbody>
              {currentUsers.map((user) => (
                <tr key={user.id}>
                  <td>{user.id}</td>
                  <td>{user.email}</td>
                  <td>{user.name}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="pagination">
            <button
              className="user-button"
              onClick={handleClickPrev}
              disabled={totalPages === 1 || currentIndex === 0}
            >
              Назад
            </button>
            <span className="text">{`Страница ${
              currentIndex + 1
            } из ${totalPages}`}</span>
            <button
              className="user-button"
              onClick={handleClickNext}
              disabled={totalPages === 1 || currentIndex === totalPages - 1}
            >
              Вперед
            </button>
          </div>
        </>
      ) : (
        <p>Нет доступных пользователей.</p>
      )}
    </div>
  );
}

export default UserList;
