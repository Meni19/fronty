import "./ListsStyles.css";

import React, { useState, useEffect } from "react";
import{ fetchProducts } from "../../APIs/product/ProductAPI"
import { fetchTypes, deleteType } from "../../APIs/product/TypeAPI";

function TypeList() {
  const [types, setTypes] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchTypeData = async () => {
      try {
        const data = await fetchTypes();
        setTypes(data || []);
        setLoading(false);
      } catch (error) {
        console.error("Ошибка при получении типов:", error);
        setLoading(false);
      }
    };

    fetchTypeData();
  }, []);

  const handleDeleteType = async (typeId) => {
    try {
      const productsWithThisType = await fetchProducts(null, typeId, 1, 1);

      if (productsWithThisType.rows.length > 0) {
        alert("Нельзя удалить тип, так как к нему прикреплены товары.");
      } else {
        const confirmDelete = window.confirm(
          "Вы уверены, что хотите удалить этот тип?"
        );

        if (confirmDelete) {
          const response = await deleteType(typeId);

          if (response.error) {
            alert(response.error);
          } else {
            setTypes((prevTypes) =>
              prevTypes.filter((type) => type.id !== typeId)
            );
          }
        }
      }
    } catch (error) {
      console.error("Ошибка при удалении типа:", error);
    }
  };

  if (loading) {
    return <p>Загрузка типов...</p>;
  }

  return (
    <div className="main-list">
      <h2>Список типов</h2>
      {types.length > 0 ? (
        <ul>
          {types.map((type) => (
            <li className='items-list' key={type.id}>
              {type.name}{" "}
              <button
                className="delete-button"
                onClick={() => handleDeleteType(type.id)}
              >
                Удалить
              </button>
            </li>
          ))}
        </ul>
      ) : (
        <p>Нет доступных типов.</p>
      )}
    </div>
  );
}

export default TypeList;
