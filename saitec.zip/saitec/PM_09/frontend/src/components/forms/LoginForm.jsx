import "./FormsStyles.css"
import React, { useState, useContext } from "react";
import { Form, Button } from "react-bootstrap";
import { Link, useNavigate } from "react-router-dom";
import { observer } from "mobx-react-lite";
import { signin } from "../../APIs/user/UserAPI";
import { Context } from "../../index";

const SignIn = observer(() => {
  const { user } = useContext(Context);

  const [allFieldsFilled, setAllFieldsFilled] = useState(false);

  const [login, setLogin] = useState("");
  const [password, setPassword] = useState("");

  const [errorText, setErrorText] = useState("");

  const navigate = useNavigate();

  const handleFormChange = () => {
    const formInputs = document.querySelectorAll(".form-input");
    let allFilled = true;
    formInputs.forEach((input) => {
      if (input.value === "") {
        allFilled = false;
      }
    });
    setAllFieldsFilled(allFilled);
  };

  const signInclick = async () => {
    try {
      let data = await signin(login, password);
      user.setUser(data);
      user.setIsAuth(true);
      localStorage.setItem("userId", data.id);
      console.log("Вход успешно выполнен");
      navigate("/");
      setErrorText("");
    } catch (error) {
      setErrorText(error.response.data.message);
    }
  };

  return (
    <div id="auth-form">
      <h1>Вход</h1>
      <Form.Control
        className="form-input"
        type="text"
        placeholder="Логин"
        value={login}
        onChange={(e) => {
          setLogin(e.target.value);
          handleFormChange();
        }}
      />
      <Form.Control
        className="form-input"
        type="password"
        placeholder="Пароль"
        value={password}
        onChange={(e) => {
          setPassword(e.target.value);
          handleFormChange();
        }}
      />
      <Button
        className="form-button"
        variant={allFieldsFilled ? "outline-success" : "outline-primary"}
        disabled={!allFieldsFilled}
        onClick={signInclick}
      >
        Войти
      </Button>{" "}
      {errorText && <p className="form-error-message">{errorText}</p>}
      <Link className="form-registration-link" to="/registration">Регистрация</Link>
    </div>
  );
});

export default SignIn;
