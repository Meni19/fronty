import "./FormsStyles.css"
import React, { useState, useEffect, useCallback, useContext } from "react";
import { Form, Button } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import { observer } from "mobx-react-lite";
import { registration } from "../../APIs/user/UserAPI";
import { Context } from "../../index";

const RegistrationForm = observer(() => {
  const { user } = useContext(Context);

  const [allFieldsFilled, setAllFieldsFilled] = useState(false);
  const [agreeChecked, setAgreeChecked] = useState(false);

  const [name, setName] = useState("");
  const [surname, setSurname] = useState("");
  const [patronymic, setPatronymic] = useState("");
  const [login, setLogin] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const [errorText, setErrorText] = useState("");

  const navigate = useNavigate();

  const handleFormChange = useCallback(() => {
    const formInputs = document.querySelectorAll(".form-input");
    let allFilled = true;
    formInputs.forEach((input) => {
      if (input.value === "") {
        allFilled = false;
      }
    });
    setAllFieldsFilled(allFilled && agreeChecked);
  }, [agreeChecked]);

  const handleCheckboxChange = () => {
    setAgreeChecked(!agreeChecked);
  };

  useEffect(() => {
    handleFormChange();
  }, [handleFormChange]);

  const signUpClick = async () => {
    try {
      let data = await registration(
        name,
        surname,
        patronymic,
        login,
        email,
        password,
        confirmPassword
      );
      user.setUser(data.user);
      user.setIsAuth(true);
      // console.log("Пользователь успешно зарегистрирован.");
      navigate("/login");
      setErrorText("");
    } catch (error) {
      setErrorText(error.response.data.message);
    }
  };

  return (
    <div id="auth-form">
      <h1>Регистрация</h1>
      <Form.Control
        className="form-input"
        type="text"
        placeholder="Имя"
        value={name}
        onChange={(e) => {
          setName(e.target.value);
          handleFormChange();
        }}
      />
      <Form.Control
        className="form-input"
        type="text"
        placeholder="Фамилия"
        value={surname}
        onChange={(e) => {
          setSurname(e.target.value);
          handleFormChange();
        }}
      />
      <Form.Control
        className="form-input"
        type="text"
        placeholder="Отчество"
        value={patronymic}
        onChange={(e) => {
          setPatronymic(e.target.value);
          handleFormChange();
        }}
      />
      <Form.Control
        className="form-input"
        type="text"
        placeholder="Логин"
        value={login}
        onChange={(e) => {
          setLogin(e.target.value);
          handleFormChange();
        }}
      />
      <Form.Control
        className="form-input"
        type="text"
        placeholder="Электронная почта"
        value={email}
        onChange={(e) => {
          setEmail(e.target.value);
          handleFormChange();
        }}
      />
      <Form.Control
        className="form-input"
        type="password"
        placeholder="Пароль"
        value={password}
        onChange={(e) => {
          setPassword(e.target.value);
          handleFormChange();
        }}
      />
      <Form.Control
        className="form-input"
        type="password"
        placeholder="Подтверждение пароля"
        value={confirmPassword}
        onChange={(e) => {
          setConfirmPassword(e.target.value);
          handleFormChange();
        }}
      />
      <Form.Check
        className="form-rules-check"
        required
        label="Согласен с правилами регистрации"
        feedback="Согласен"
        feedbackType="invalid"
        onChange={handleCheckboxChange}
        checked={agreeChecked}
      />
      <Button
        className="form-button"
        variant={allFieldsFilled ? "outline-success" : "outline-primary"}
        disabled={!allFieldsFilled}
        onClick={signUpClick}
      >
        Зарегистрироваться
      </Button>{" "}
      {errorText && <p className="form-error-message">{errorText}</p>}
    </div>
  );
});

export default RegistrationForm;
