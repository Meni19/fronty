import "./HeaderStyles.css";
import React, { useContext, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { Context } from "../../../index";

function Header() {
  const { user } = useContext(Context);
  const location = useLocation();

  const handleLogout = () => {
    user.setUser({});
    user.setIsAuth(false);
    localStorage.removeItem("token");
    localStorage.removeItem("userId");
  };

  const isAdmin = user.isAuth && user.user && user.user.role === "ADMIN";

  const menuItems = [
    { path: "/store", title: "Каталог", image: "/images/shop.svg" },
    {
      path: "/basket",
      title: "Корзина",
      visible: user.isAuth,
      image: "/images/basket.svg",
    },
    {
      path: "/user",
      title: "Профиль",
      visible: user.isAuth,
      image: "/images/basket.svg",
    },
    {
      path: "/login",
      title: user.isAuth ? "Выйти" : "Войти",
      onClick: user.isAuth ? handleLogout : null,
      image: user.isAuth ? "/images/user.svg" : "/images/user.svg",
    },

    isAdmin && {
      path: "/admin",
      title: "Админ панель",
      image: "/images/admin.svg",
    },
  ].filter((item) => item);

  useEffect(() => {}, [user.user]);

  return (
    <div className="header">
      <ul className="items">
        <Link className="small" to="/">
          <img
            className="small-logo-image"
            src="/images/small1.jpg"
            alt="logo"
          />
        </Link>
        {menuItems.map(
          ({ path, title, onClick, visible }) =>
            visible !== false && (
              <li
                className={`item ${
                  location.pathname === path ? "active" : "passive"
                }`}
                key={path}
              >
                {location.pathname === path ? (
                  <>
                    <div className="active">
                      <div className="item-body">
                        {/* <img className="item-image" src={image} alt={title} /> */}
                        <div className="item-title">{title}</div>
                      </div>
                    </div>
                  </>
                ) : (
                  <Link className="passive" to={path} onClick={onClick}>
                    <div className="item-body">
                      {/* <img className="item-image" src={image} alt={title} /> */}
                      <div className="item-title">{title}</div>
                    </div>
                  </Link>
                )}
              </li>
            )
        )}
      </ul>
    </div>
  );
}

export default Header;
