import "bootstrap/dist/css/bootstrap.min.css";
import React, { createContext } from "react";
import { createRoot } from "react-dom/client";
import Modal from "react-modal";
import UserStore from "./store/UserStore";
import App from "./render/App";

export const Context = createContext(null);

const root = createRoot(document.getElementById("root"));

Modal.setAppElement("#root");

root.render(
  <React.StrictMode>
    <Context.Provider value={{ user: new UserStore() }}>
      <App />
    </Context.Provider>
  </React.StrictMode>
);
