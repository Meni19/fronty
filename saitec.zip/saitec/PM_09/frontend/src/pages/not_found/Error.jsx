import "./ErrorStyles.css"
import React from "react";
import { Link } from "react-router-dom";

function Error() {
  return (
    <div className="error-container">
      <h1 className="big-404">404</h1>
      <h1>Страница не найдена</h1>
      <Link to="/" style={{ textDecoration: 'none'}}>На главную страницу</Link>
    </div>
  );
}

export default Error;
