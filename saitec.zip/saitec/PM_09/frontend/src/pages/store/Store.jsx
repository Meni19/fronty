
import React, { useState, useEffect } from "react";
import { useLocation } from "react-router-dom";
import TypeBar from "@components/bars/TypeBar";
import BrandBar from "@components/bars/BrandBar";
import ProductList from "@components/product/product_list/ProductList";

function Store() {
  const [selectedType, setSelectedType] = useState(null);
  const [selectedBrand, setSelectedBrand] = useState(null);
  const [page, setPage] = useState(1);
  const [limit] = useState(8);
  const location = useLocation();

  useEffect(() => {
    const searchParams = new URLSearchParams(location.search);
    const brandId = searchParams.get("brandId");
    if (brandId) {
      setSelectedBrand(parseInt(brandId));
    }
  }, [location.search]);

  return (
    <section className="store-page">
      <div className="types-brands">
        <TypeBar setSelectedType={setSelectedType} setPage={setPage} />
        <BrandBar setSelectedBrand={setSelectedBrand} setPage={setPage} />
      </div>

      <div className="product-list">
        <ProductList
          page={page}
          setPage={setPage}
          limit={limit}
          selectedType={selectedType}
          selectedBrand={selectedBrand}
        />
      </div>
    </section>
  );
}

export default Store;
