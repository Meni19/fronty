import "./ContactsStyles.css"

function Contacts() {
    return (
      <div className="contacts">
        <img className="map" src="/images/map.png" alt="mi tuta"/> 
        <h1 className="big-text">Мы находимся по адресу</h1>
        <h3 className="small-text">Г. Владимир, ул. Большая Москвоская, д. 18 </h3>
        <h1 className="big-text">Электронная почта </h1>
        <h3 className="small-text">kompik33@store.ru</h3>
        <h1 className="big-text">Телефон</h1>
        <h3 className="small-text">+7 (900) 555-35-35</h3>
      </div>
      
    )
  }
  


  export default Contacts;
  