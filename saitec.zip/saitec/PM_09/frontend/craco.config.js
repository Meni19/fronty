const path = require('path');

const resolvePath = p => path.resolve(__dirname, p)

module.exports = {
    // ...
    webpack: {
        alias: {
            '@APIs': resolvePath('./src/APIs'),
            '@components': resolvePath('./src/components'),
            '@pages': resolvePath('./src/pages'),
            '@render': resolvePath('./src/render'),
            '@store': resolvePath('./src/store'),
        }
    },
  // ...
}